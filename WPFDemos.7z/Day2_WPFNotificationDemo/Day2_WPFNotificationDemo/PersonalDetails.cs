﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Day2_WPFNotificationDemo
{
    class PersonalDetails:INotifyPropertyChanged
    {
        private string _firstname, _lastname;

        public event PropertyChangedEventHandler
            PropertyChanged;

        public void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
                PropertyChanged(this,
                    new PropertyChangedEventArgs(property));
        }

        public string FirstName
        {
            get { return _firstname; }
            set
            {
                _firstname = value;
               OnPropertyChanged("FullName");
            }
        }

        public string LastName
        {
            get { return _lastname; }
            set {
                _lastname = value;
               OnPropertyChanged("FullName");
            }
        }

        public string FullName
        {
            get
            {
                return string.Format("{0} {1}", _firstname, _lastname);
            }
        }
                
    }
}
