﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//.Net data Providers for Sql Server

namespace Day1_ConnectedExamples
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            //conn.ConnectionString = 
            //    @"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_17Jan2018_Bangalore;User id=sqluser;password=sqluser";

            conn.ConnectionString = 
                "Data Source=.;Initial Catalog=ContactsDB;Integrated Security=true";

            conn.Open();//opens the database connection

            string str = "Server Name = " + conn.DataSource;
            str += "\nDatabase Name =" + conn.Database;
            str += "\nServer Version = " + conn.ServerVersion;
            str += "\nConnection String =" + conn.ConnectionString;

            MessageBox.Show(str);

            conn.Close();//closes the database connection
        }
    }
}
