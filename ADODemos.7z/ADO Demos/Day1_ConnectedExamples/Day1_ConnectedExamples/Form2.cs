﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;//to use configuration manager class

namespace Day1_ConnectedExamples
{
    public partial class Form2 : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader dr;
        string data = "";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.
                ConnectionStrings["mycon"].ConnectionString;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select staff_code,staff_name from Staff_Master";

            conn.Open();

            dr = cmd.ExecuteReader();

            if (dr.HasRows)//Check whether rows are returned or not
            {
                while (dr.Read())
                {
                    //data = dr[0].ToString() + "-->" + dr[1].ToString();
                    data = dr.GetDecimal(0).ToString() + "--->" + dr.GetString(1);
                    listBox1.Items.Add(data);
                }
            }

            dr.Close();
            conn.Close();
        }
    }
}
