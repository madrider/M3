﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day1_ConnectedExamples
{
    public partial class Form7 : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.Connection = conn;

            //cmd.CommandText = "insert into Participants values(" + txtID.Text + ",'" + txtName.Text + "','" + txtEmail.Text + "'," + txtContact.Text + ")";
            cmd.CommandText = "insert into Participants values(@id,@name,@email,@contact)";

            cmd.Parameters.AddWithValue("@id", txtID.Text);
            cmd.Parameters.AddWithValue("@name", txtName.Text);
            cmd.Parameters.AddWithValue("@email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@contact", txtContact.Text);

            conn.Open();

            int result = cmd.ExecuteNonQuery();

            if(result>0)
                MessageBox.Show("Record Inserted");
            ClearFields();

            conn.Close();
        }

        private void ClearFields()
        {
            txtID.Text = "";
            txtName.Text = "";
            txtContact.Text = "";
            txtEmail.Text = "";
        }
        private void Form7_Load(object sender, EventArgs e)
        {
            conn = new
                SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
        }
    }
}
