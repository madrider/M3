﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Day1_ConnectedExamples
{
    public partial class Form4 : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader dr;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["nwcon"].ConnectionString;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.CommandText = "[Ten Expensive Products]";
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();

            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

            while(dr.Read())
            {
                var data = dr[0].ToString()+"--->"+dr[1].ToString();
                listBox1.Items.Add(data);
            }

            dr.Close();

            
        }
    }
}
