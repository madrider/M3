﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Day1_ConnectedExamples
{
    public partial class Form5 : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader dr;
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(
                ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "GetStaffInfo";
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter codeparam = new
                SqlParameter("@code", DbType.Decimal);

            cmd.Parameters.Add(codeparam);//adds the paramter object to the parameter list of command object
            cmd.Parameters["@code"].Value = txtID.Text;

            conn.Open();

            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();
                txtName.Text = dr[0].ToString();
                txtHiredate.Text = dr[1].ToString();
                txtSalary.Text = dr[2].ToString();
            }
            else
            {
                MessageBox.Show("No Staff with Such ID");
            }

            dr.Close();
            conn.Close();
        }
    }
}
