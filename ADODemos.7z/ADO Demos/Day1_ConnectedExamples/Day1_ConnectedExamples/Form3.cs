﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day1_ConnectedExamples
{
    public partial class Form3 : Form
    {
        SqlConnection conn;
        SqlCommand cmd;

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["nwcon"].ConnectionString;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select count(*) from Products", conn);

            conn.Open();

            var result = cmd.ExecuteScalar();

            MessageBox.Show("No Of Products=" + result);

            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            cmd = new SqlCommand("select min(UnitPrice) from Products", conn);

            conn.Open();

            var result = cmd.ExecuteScalar();

            MessageBox.Show("Minimum Price=" + result);

            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            cmd = new SqlCommand("select max(UnitPrice) from Products", conn);

            conn.Open();

            var result = cmd.ExecuteScalar();

            MessageBox.Show("Maximum Price=" + result);

            conn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select sum(UnitPrice) from Products", conn);

            conn.Open();

            var result = cmd.ExecuteScalar();

            MessageBox.Show("Total Price=" + result);

            conn.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select avg(UnitPrice) from Products", conn);

            conn.Open();

            var result = cmd.ExecuteScalar();

            MessageBox.Show("Average Price=" + result);

            conn.Close();
        }
    }
}
