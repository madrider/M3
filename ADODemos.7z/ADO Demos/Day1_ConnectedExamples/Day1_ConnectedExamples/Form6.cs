﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day1_ConnectedExamples
{
    public partial class Form6 : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("GetStaffCountByManager", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter mgridparam = new
                SqlParameter("@mgrid", DbType.Decimal);

            SqlParameter empcount = new
                SqlParameter("@count", DbType.Int32);
            empcount.Direction = ParameterDirection.Output;

            cmd.Parameters.Add(mgridparam);
            cmd.Parameters["@mgrid"].Value = textBox1.Text;

            cmd.Parameters.Add(empcount);

            conn.Open();

            cmd.ExecuteNonQuery();

            int count = (int)cmd.Parameters["@count"].Value;

            MessageBox.Show("No of Employees ="+count);

            conn.Close();
        }
    }
}
