﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Configuration;
using EMS.Entities;
using EMS.Exceptions;
using System.Data;

namespace EMS.DAL
{
    public class EmployeeDAL
    {
        SqlCommand cmd;
        SqlConnection conn = 
            new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
        SqlDataReader dr;

        public bool AddEmployeeDAL(Employee emp)
        {
            bool empAdded = false;

            try
            {
                cmd = new SqlCommand("Insertemployee", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", emp.Name);
                cmd.Parameters.AddWithValue("@dob", emp.DOB);
                cmd.Parameters.AddWithValue("@contact", emp.Contact);
                cmd.Parameters.AddWithValue("@email", emp.Email);

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    empAdded = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return empAdded;
        }

        public bool UpdateEmployeeDAL(Employee emp)
        {
            bool empUpdated = false;
            try
            {
                cmd = new SqlCommand("updateemployee", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", emp.Name);
                cmd.Parameters.AddWithValue("@dob", emp.DOB);
                cmd.Parameters.AddWithValue("@contact", emp.Contact);
                cmd.Parameters.AddWithValue("@email", emp.Email);
                cmd.Parameters.AddWithValue("@id", emp.Id);

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    empUpdated = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return empUpdated;
        }

        public bool DeleteEmployeeDAL(int id)
        {
            bool empdeleted = false;

            try
            {
                cmd = new SqlCommand("DeleteEmployee", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    empdeleted = true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return empdeleted;
        }

        public Employee SearchEmployeeDAL(int id)
        {
            Employee emp = null;

            try
            {
                cmd = new SqlCommand("SearchEmployee", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);

                conn.Open();

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();

                    emp = new Employee();
                    emp.Id = dr.GetInt32(0);
                    emp.Name = dr.GetString(1);
                    emp.DOB = dr.GetDateTime(2);
                    emp.Contact = dr.GetString(3);
                    emp.Email = dr.GetString(4);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return emp;
        }

        public List<Employee> GetEmployeeDAL()
        {
            List<Employee> emp = null;

            try
            {
                cmd = new SqlCommand("GetEmployees", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                conn.Open();

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    emp = new List<Employee>();

                    while (dr.Read())
                    {
                        Employee e = new Employee();
                        e.Id = dr.GetInt32(0);
                        e.Name = dr.GetString(1);
                        e.DOB = dr.GetDateTime(2);
                        e.Contact = dr.GetString(3);
                        e.Email = dr.GetString(4);

                        emp.Add(e);
                    }
                }
                    
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                conn.Close();
            }

            return emp;
        }

    }
}
