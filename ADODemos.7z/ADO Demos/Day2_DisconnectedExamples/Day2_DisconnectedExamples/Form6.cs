﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day2_DisconnectedExamples
{
    public partial class Form6 : Form
    {
        SqlConnection conn;
        SqlDataAdapter adp;
        DataSet ds;
        DataView dv;
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            conn = new
               SqlConnection(ConfigurationManager.ConnectionStrings["nwcon"].ConnectionString);

            adp = new SqlDataAdapter("select * from dbo.Products", conn);

            ds = new DataSet();

            adp.Fill(ds, "Products");

            dv = new DataView(ds.Tables[0]);

            dataGridView1.DataSource = dv;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            dv.RowFilter = "ProductName like '" + txtSearch.Text + "%'";
        }
    }
}
