﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Day2_DisconnectedExamples
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);

            conn.Open();

            //Creating a Sql Transaction Object
            SqlTransaction trans = conn.BeginTransaction();

            //Creating Insert Command
            SqlCommand insertcmd = new SqlCommand("insert into EmployeeDetails(FirstName,Lastname,PostionCode,Age,Address,Gender) values(@fname,@lname,@pcode,@age,@address,@gender)",conn);

            insertcmd.Parameters.AddWithValue("@fname", txtFN.Text);
            insertcmd.Parameters.AddWithValue("@lname", txtLN.Text);
            insertcmd.Parameters.AddWithValue("@pcode", txtPCode.Text);
            insertcmd.Parameters.AddWithValue("@age", txtAge.Text);
            insertcmd.Parameters.AddWithValue("@address", txtAddress.Text);
            insertcmd.Parameters.AddWithValue("@gender", txtGender.Text);

            //Adds the command object to transaction
            insertcmd.Transaction = trans;

            //Creating Update Command
            SqlCommand updatecmd = new SqlCommand("update EmployeePosition set CurrentStrength=CurrentStrength+1 where Positioncode=@code", conn);

            updatecmd.Parameters.AddWithValue("@code", txtPCode.Text);

            updatecmd.Transaction = trans;

            try
            {
                insertcmd.ExecuteNonQuery();
                updatecmd.ExecuteNonQuery();

                trans.Commit();//Finialize the Transaction

                MessageBox.Show("Employee Added Successfully");
            }
            catch (Exception ex)
            {
                trans.Rollback();//Rollback chanages back to database
                MessageBox.Show(ex.Message);
            }

            conn.Close();
        }
    }
}
