﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day2_DisconnectedExamples
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["nwcon"].ConnectionString;

            SqlDataAdapter adp = new SqlDataAdapter("select * from dbo.Customers", conn);

            DataSet ds = new DataSet();

            adp.Fill(ds, "Customers");

            //Creating DataView Object
            DataView dvUSA = new DataView(ds.Tables["Customers"]);
            DataView dvMexico = new DataView(ds.Tables["Customers"]);

            //Filtering Data Using DataView
            dvUSA.RowFilter = "Country='USA'";
            dvMexico.RowFilter = "Country='Mexico'";

            //Sorting Data
            dvMexico.Sort = "CustomerID desc";

            //Binding DataView to DataGridView
            dgvCustUS.DataSource = dvUSA;
            dgvCustMexico.DataSource = dvMexico;
        }
    }
}
