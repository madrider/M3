﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//to use data adapter class
using System.Data;//to use dataset or datatable class
using System.Configuration;

namespace Day2_DisconnectedExamples
{
    public partial class Form1 : Form
    {
        SqlConnection conn;
        SqlDataAdapter adp;
        DataSet ds;
        public Form1()
        {
            InitializeComponent();

            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Creating a DataAdapter Object
            adp = new SqlDataAdapter("select * from Student_Master", conn);

            //Creating a Dataset object
            ds = new DataSet();

            //Fill DataSet 
            adp.Fill(ds, "students");

            //Binding Data to GridView Control
            //dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.DataSource = ds.Tables["students"];
        }
    }
}
