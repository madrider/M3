﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Day2_DisconnectedExamples
{
    public partial class Form7 : Form
    {
        SqlConnection conn;
        SqlDataAdapter adp;
        SqlCommandBuilder builder;
        DataSet ds;
       
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;

            adp = new SqlDataAdapter("select * from Participants", conn);

            builder = new SqlCommandBuilder(adp);

            ds = new DataSet();

            adp.Fill(ds);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow row = ds.Tables[0].NewRow();

                MessageBox.Show("Current row status = " + row.RowState.ToString());

                //Adding Data to Row
                row["Id"] = txtID.Text;
                row["Name"] = txtName.Text;
                row["Contact"] = txtContact.Text;
                row["Email"] = txtEmail.Text;

                ds.Tables[0].Rows.Add(row);

                MessageBox.Show("Current row status = " + row.RowState.ToString());

                //Update the database
                adp.Update(ds);

                MessageBox.Show("Record Inserted");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
