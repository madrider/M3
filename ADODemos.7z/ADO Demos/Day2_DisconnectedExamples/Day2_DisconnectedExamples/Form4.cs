﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Day2_DisconnectedExamples
{
    public partial class Form4 : Form
    {
        SqlConnection conn;
        SqlDataAdapter adp;
        DataSet ds;
        DataRelation dr;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["nwcon"].ConnectionString);

            adp = new SqlDataAdapter("select * from dbo.Categories", conn);

            ds = new DataSet();

            adp.Fill(ds, "Category");

            adp.SelectCommand.CommandText = "select * from dbo.Products";

            adp.Fill(ds, "Products");

            DataColumn parentColumn =
                ds.Tables["Category"].Columns["CategoryId"];

            DataColumn childColumn =
                ds.Tables["Products"].Columns["CategoryId"];

             dr = 
                new DataRelation("catprod", parentColumn, childColumn);

            ds.Relations.Add(dr);//adds the datarelation to dataset

            foreach (DataRow row in ds.Tables["Category"].Rows)
            {
                lstCategories.Items.Add(row["CategoryName"]);
            }
        }

        private void lstCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstProducts.Items.Clear();

            DataRow[] rows = ds.Tables["Category"].
                Select("CategoryName='" + lstCategories.Text + "'");

            DataRow parent = rows[0];

            foreach (DataRow child in parent.GetChildRows(dr))
            {
                lstProducts.Items.Add(child["ProductName"]);
            }
        }
    }
}
