create table EmployeesDetails
(
Id int identity primary key,
Name varchar(100) not null,
Dob datetime not null,
Contact varchar(10) not null,
Email varchar(100) not null
)

--Stored Procedure
--For Insert
go 
create proc InsertEmployee(@name varchar(100),@dob datetime,@contact varchar(10),@email varchar(100))
as
begin
insert into EmployeesDetails(name,Dob,Contact,Email) values(@name,@dob,@contact,@email)
end 
go

--For Update
go 
create proc UpdateEmployee(@id int,@name varchar(100),@dob datetime,@contact varchar(10),@email varchar(100))
as
begin
Update EmployeesDetails
set Name=@name,Dob=@dob,Contact=@contact,Email=@email
where Id=@id
end 
go

--For Delete
go
create proc DeleteEmployee(@id int)
as
begin
delete from EmployeesDetails where Id=@id
end
go

--For Search
go
create proc SearchEmployee(@id int)
as
begin
select * from EmployeesDetails where Id=@id
end
go

--For Display All 
go
create proc GetEmployees
as
begin
select * from EmployeesDetails 
end
go

