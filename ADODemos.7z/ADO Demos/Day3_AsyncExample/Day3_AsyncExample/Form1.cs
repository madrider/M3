﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day3_AsyncExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=ndamssql\sqlilearn;initial catalog=training_17jan2018_bangalore;uid=sqluser;pwd=sqluser";

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from Student_Master WAITFOR delay '00:00:05'";
            cmd.Connection = conn;

            await conn.OpenAsync();

            SqlDataReader dr = await cmd.ExecuteReaderAsync();

            while (dr.Read())
            {
                MessageBox.Show(dr[1].ToString());
            }

            dr.Close();
            conn.Close();
        }
    }
}
