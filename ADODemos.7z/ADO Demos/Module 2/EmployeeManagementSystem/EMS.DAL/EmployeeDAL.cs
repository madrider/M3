﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EMS.Exceptions;//Accessing Custom Exception Class
using EMS.Entities;//Accessing Entity Classes

namespace EMS.DAL
{

    public class EmployeeDAL
    {
        private static List<Employee> emplist = new List<Employee>();

        //Adding Employee to Collection
        public bool AddEmployeeDAL(Employee emp)
        {
            bool empAdded = false;

            try
            {
                emplist.Add(emp);
                empAdded = true;
            }
            catch (Exception ex)
            {
                throw new EmployeeException(ex.Message);
            }

            return empAdded;
        }

        //Displaying all the Employees
        public List<Employee> GetEmployeeDAL()
        {
            if (emplist == null)
                throw new EmployeeException("List is Empty");
            else
            return emplist;
        }

        //Searching Employee
        public Employee SearchEmployeeDAL(int id)
        {
            Employee emp = null;

            foreach (Employee e in emplist)
            {
                if (e.Id == id)
                {
                    emp = e;
                    break;
                }
            }

            return emp;
        }
    }
}
