﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EMS.Entities;
using EMS.Exceptions;
using EMS.DAL;

namespace EMS.BLL
{
    public class EmployeeBLL
    {
        private static bool Validate(Employee emp)
        {
            StringBuilder sb = new StringBuilder();
            bool validemp = true;

            if(emp.Id<=0)
            {
                validemp = false;
                sb.Append("\nEmployee Id Cannot be Zero or Negative");
            }

            if (emp.Name == string.Empty)
            {
                validemp = false;
                sb.Append("\nName cannot be blank");
            }

            if (emp.DOB == DateTime.Now)
            {
                validemp = false;
                sb.Append("\nDate of Birth Cannot be current date");
            }

            if(emp.Contact==string.Empty)
            {
                validemp = false;
                sb.Append("\nContact cannot be blank");
            }

            if (emp.Contact.Length < 10 || emp.Contact.Length > 10)
            {
                validemp = false;
                sb.Append("\nContact No must be of 10 digits");
            }

            if (emp.Email == string.Empty)
            {
                validemp = false;
                sb.Append("\nEmail Cannot be blank");
            }

            if (validemp == false)
                throw new EmployeeException(sb.ToString());

            return validemp;
        }

        public static bool AddEmployeeBLL(Employee emp)
        {
            bool empAddded=false;

            try
            {
                if (Validate(emp))
                {
                    EmployeeDAL objDal = new EmployeeDAL();
                    empAddded = objDal.AddEmployeeDAL(emp);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return empAddded;
        }

        public static List<Employee> GetEmployeeBLL()
        {
            List<Employee> elist = null;

            try
            {
                EmployeeDAL objDal = new EmployeeDAL();
                elist = objDal.GetEmployeeDAL();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return elist;
        }

        public static Employee SearchEmployeeBLL(int id)
        {
            Employee emp = null;

            try
            {
                EmployeeDAL objDal = new EmployeeDAL();
                emp = objDal.SearchEmployeeDAL(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return emp;
        }
    }
}
