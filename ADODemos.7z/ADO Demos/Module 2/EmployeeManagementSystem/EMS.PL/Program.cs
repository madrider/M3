﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EMS.BLL;
using EMS.Entities;
using EMS.Exceptions;
namespace EMS.PL
{
    class Program
    {
        static void AddEmployee()
        {
            try
            {
                Employee emp = new Employee();

                Console.WriteLine("Enter Id");
                emp.Id = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Name");
                emp.Name = Console.ReadLine();

                Console.WriteLine("Enter DOB");
                emp.DOB = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Enter Contact");
                emp.Contact = Console.ReadLine();

                Console.WriteLine("Enter Email");
                emp.Email = Console.ReadLine();

                if (EmployeeBLL.AddEmployeeBLL(emp))
                {
                    Console.WriteLine("Employee Added Sucessfully");
                }
                else
                {
                    Console.WriteLine("Unable to Add Employee");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void GetAllEmployee()
        {
            try
            {
                List<Employee> elist = EmployeeBLL.GetEmployeeBLL();

                if (elist != null)
                {
                    Console.WriteLine("ID-->Name-->DOB-->Contact-->Email");
                    Console.WriteLine("---------------------------------------------");

                    foreach (Employee e in elist)
                    {
                        Console.WriteLine("{0}-->{1}-->{2}-->{3}-->{4}",
                            e.Id, e.Name, e.DOB.ToShortDateString(),
                            e.Contact, e.Email);
                    }
                }
                else
                {
                    Console.WriteLine("No Employee to Display");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void SearchEmployee()
        {
            try
            {
                Console.WriteLine("Enter Employee id to search");
                int id = Convert.ToInt32(Console.ReadLine());

                Employee emp = EmployeeBLL.SearchEmployeeBLL(id);

                if (emp != null)
                {
                    Console.WriteLine("Employee Information");
                    Console.WriteLine("Id =" + emp.Id);
                    Console.WriteLine("Name =" + emp.Name);
                    Console.WriteLine("DOB =" + emp.DOB);
                    Console.WriteLine("Contact =" + emp.Contact);
                    Console.WriteLine("Email =" + emp.Email);
                }
                else
                {
                    Console.WriteLine("Employee not found");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void PrintMenu()
        {
            Console.WriteLine("***********Employee Management System*****************");
            Console.WriteLine("1.Add Employee");
            Console.WriteLine("2.Display All Employee");
            Console.WriteLine("3.Search Employee");
            Console.WriteLine("4.Exit");
            Console.WriteLine("******************************************************");
        }
        static void Main(string[] args)
        {
            int choice;

            while(true)
            {
                PrintMenu();
                Console.WriteLine("Enter your choice");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;

                    case 2:
                        GetAllEmployee();
                        break;

                    case 3:
                        SearchEmployee();
                        break;

                    case 4:
                        return;

                    default:
                        Console.WriteLine("Invalid Choice Try Again");
                        break;
                            
                }
            }
        }
    }
}
