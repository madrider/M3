﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Security;

namespace Day3_SqlCredentialWPFExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string sqlcon = @"Data Source=NDAMSSQL\SQLILEARN;
                        Initial Catalog=Northwind";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(sqlcon))
            {
                SecureString pass = txtpass.SecurePassword;
                pass.MakeReadOnly();

                SqlCredential cred = new SqlCredential(txtuname.Text, pass);

                conn.Credential = cred;

                try
                {
                    conn.Open();

                    MessageBox.Show("Login Successful");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Login Unsuccessful....");
                    //MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }
    }
}
