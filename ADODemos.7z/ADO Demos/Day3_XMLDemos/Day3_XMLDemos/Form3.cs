﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Day3_XMLDemos
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            XmlDocument xmlDoc = new XmlDocument();

            XmlNode rootNode = xmlDoc.CreateElement("users");
            xmlDoc.AppendChild(rootNode);

            XmlNode userNode = xmlDoc.CreateElement("user");
            XmlAttribute attribute = xmlDoc.CreateAttribute("age");

            attribute.Value = "42";
            userNode.Attributes.Append(attribute);

            userNode.InnerText = "Shrikant Reddy";
            rootNode.AppendChild(userNode);

            userNode = xmlDoc.CreateElement("user");
            attribute = xmlDoc.CreateAttribute("age");
            attribute.Value = "39";

            userNode.Attributes.Append(attribute);
            userNode.InnerText = "Anil Jain";
            rootNode.AppendChild(userNode);

            xmlDoc.Save("UsersData.xml");

            MessageBox.Show("File Create Successfully...");
        }

      
    }
}
