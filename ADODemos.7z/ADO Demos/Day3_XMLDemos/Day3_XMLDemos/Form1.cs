﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day3_XMLDemos
{
    public partial class Form1 : Form
    {
        SqlConnection conn;
        SqlDataAdapter adp;
        DataSet ds;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_17Jan2018_Bangalore;User ID=sqluser;Password=sqluser";

            adp = new SqlDataAdapter("select * from Student_Master", conn);

            ds = new DataSet();

            adp.Fill(ds, "Student");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ds.WriteXml("StudentDetails.xml");

            MessageBox.Show("Data Exported to XML");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            StreamReader dr = new StreamReader("Accounts.xml");
            DataSet dsXml = new DataSet();
            dsXml.ReadXml(dr);

            MessageBox.Show("Data imported to Dataset");

            dataGridView1.DataSource = dsXml.Tables[0];
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ds.WriteXmlSchema("Student.xsd");

            MessageBox.Show("Schema Created...");
        }
    }
}
